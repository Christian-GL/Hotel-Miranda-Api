
export enum RoomType {
    suite = "Suite",
    singleBed = "Single Bed",
    doubleBed = "Double Bed",
    doubleSuperior = "Double Superior"
}
