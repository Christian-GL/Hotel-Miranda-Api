
export enum RoomAmenities {
    bedSpace3 = "3 Bed Space",
    bathroom2 = "2 Bathroom",
    wiFi = "WiFi",
    tv = "TV",
    ledTv = "LED TV",
    airConditioner = "Air Conditioner",
    minibar = "Minibar",
    balcony = "Balcony",
    shower = "Shower",
    towel = "Towel",
    bathtub = "Bathup",
    coffeeSet = "Cofee Set",
    guard24Hours = "24 Hours Guard"
}
