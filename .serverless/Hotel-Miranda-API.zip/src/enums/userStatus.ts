
export enum UserStatus {
    active = "active",
    inactive = "inactive"
}