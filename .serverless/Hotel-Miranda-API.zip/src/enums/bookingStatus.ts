
export enum BookingStatus {
    checkIn = "Check In",
    inProgress = "In Progress",
    checkOut = "Check Out"
}
